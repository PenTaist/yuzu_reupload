1) Open terminal in this folder

2) Execute following commands :

- sudo chmod +x liftinstall
- sudo ./liftinstall

ENJOY :)
