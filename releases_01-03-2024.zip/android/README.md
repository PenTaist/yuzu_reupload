1) Download the Yuzu APK file --> https://apkpure.fr/fr/yuzu-emulator/org.yuzu.yuzu_emu

2) Launch the file with the android APK installer

3) Install the app

ENJOY :)
