1) Launch "VC_redist.x64.exe" --> http://aka.ms/vs/17/release/vc_redist.x64.exe

2) Launch "yuzu_install.exe"

ENJOY :)
